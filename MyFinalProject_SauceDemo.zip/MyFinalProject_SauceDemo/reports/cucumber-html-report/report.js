$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/Feature/Test.feature");
formatter.feature({
  "line": 2,
  "name": "SauceDemo_Website",
  "description": "",
  "id": "saucedemo-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@SauceDemo"
    }
  ]
});
formatter.scenario({
  "line": 111,
  "name": "",
  "description": "checking invalid partnership details in company field",
  "id": "saucedemo-website;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 110,
      "name": "@TC13_Invalid_partnership_details_in_the_company_field"
    }
  ]
});
formatter.step({
  "line": 113,
  "name": "the user launch the chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 114,
  "name": "the user open the Sauce_demo Home page",
  "keyword": "When "
});
formatter.step({
  "line": 115,
  "name": "The user login the home page",
  "keyword": "Then "
});
formatter.step({
  "line": 116,
  "name": "check Invalid partnership details in the company field",
  "keyword": "Then "
});
formatter.step({
  "line": 117,
  "name": "close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "Sauce_demo_stepdefinition.the_user_launch_the_chrome_application()"
});
formatter.result({
  "duration": 10057572330,
  "status": "passed"
});
formatter.match({
  "location": "Sauce_demo_stepdefinition.the_user_open_the_Sauce_demo_Home_page()"
});
formatter.result({
  "duration": 2572627790,
  "status": "passed"
});
formatter.match({
  "location": "Sauce_demo_stepdefinition.the_user_login_the_home_page()"
});
formatter.result({
  "duration": 9894888646,
  "status": "passed"
});
formatter.match({
  "location": "Sauce_demo_stepdefinition.check_Invalid_partnership_details_in_the_company_field()"
});
formatter.result({
  "duration": 62757250112,
  "status": "passed"
});
formatter.match({
  "location": "Sauce_demo_stepdefinition.close_the_browser()"
});
formatter.result({
  "duration": 3122167028,
  "status": "passed"
});
});